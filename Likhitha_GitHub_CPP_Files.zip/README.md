# C++ OOP Lab Programs

## Task 1 - Student Marks Register
`Likhitha_Task1_Student_Marks_Register.cpp`

Concepts:
- Encapsulation
- Parameterized constructor
- Function overloading
- Static data member
- Friend function
- Operator overloading
- Dynamic memory management
- Copy constructor and assignment operator

Compile:
```bash
g++ -std=c++17 -Wall -Wextra -pedantic Likhitha_Task1_Student_Marks_Register.cpp -o task1
```

## Task 2 - Student Result Management System
`Likhitha_Task2_Student_Result_Management.cpp`

Concepts:
- Inheritance
- Runtime polymorphism
- STL vector
- Exception handling
- File handling
- STL algorithm
- Lambda expression

Compile:
```bash
g++ -std=c++17 -Wall -Wextra -pedantic Likhitha_Task2_Student_Result_Management.cpp -o task2
```
